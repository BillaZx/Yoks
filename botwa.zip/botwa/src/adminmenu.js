const adminmenu = (prefix) => { 
	return `
╔══✪〘 ADMIN 〙✪══
║
║
╠➥ *${prefix}ban @tagmember*
╠➥ *${prefix}unban @tagmember*
╠➥ *${prefix}spamcall [81273xxxx]*
╠➥ *${prefix}kickall*
╠➥ *${prefix}leave*
╠➥ *${prefix}promote*
╠➥ *${prefix}demote*
╠➥ *${prefix}delete*
╠➥ *${prefix}add 62813xxxxx*
╠➥ *${prefix}kickall*
╠➥ *${prefix}tagall*
╠➥  *${prefix}otagall*
╠➥  *${prefix}otagall2*
╠➥  *${prefix}tagall*
╠➥  *${prefix}setdesc*
╠➥  *${prefix}setname*
╠➥  *${prefix}kick* [tag]
╠➥  *${prefix}add* [628xxx]
╠➥  *${prefix}promote* [tag]
╠➥  *${prefix}demote* [tag]
╠➥  *${prefix}group* [buka]
╠➥  *${prefix}group* [tutup]
╠➥  *${prefix}linkgc*
╠➥  *${prefix}setpp* [foto kau]
╠➥  *${prefix}groupinfo*
╠➥  *${prefix}tagme*
╠➥  *${prefix}nsfw* [1/0]
╠➥  *${prefix}anime* [1/0]
╠➥  *${prefix}simih* [1/0]
╠➥  *${prefix}welcome* [1/0]
╠➥  *${prefix}edotensei*
╠➥  *${prefix}listadmins*
╠➥  *${prefix}ping*
╚═〘 YOKS BOT 〙`
}
exports.adminmenu = adminmenu